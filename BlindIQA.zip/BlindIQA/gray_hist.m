function [score]=gray_hist(img)


%%set some parameters 
if (nargin > 1)
    score = -1;
    return;
end
[M N] = size(img);
if (M < 16 | N < 16)
    score = -2;
    return;
end



%%converse into gray images 
gray =rgb2gray(img);
[counts,x]=imhist(gray,256); 



%%count gray series and judge whether the gray beep happened.
sum=0;
for i=1:255
    if i==1
        val=counts(i,1);
        if abs(val-counts(i+1,1))>250
            sum=sum+1;
        end
    else
    if i==255
        val=counts(i,1);
        if abs(val-counts(i-1,1))>250
            sum=sum+1;
        end
    else
        val=counts(i,1);
        val_l=counts(i-1,1);
        val_r=counts(i+1,1);
        if abs(val-val_l)>300||abs(val-val_r)>250
             sum=sum+1;
        end
    end
    end
end 
%figure;
%imhist(gray);

%%calculate the score and return
score=sum/255;
score