% %30.846
% %28.529
% %43.317
% %23.003
%  %/Users/wuweipeng/Downloads/IVC_SubQualityDB/color/
%         clc;clear;
%              sum=0;
%              a=[];
%              InputPath='/Users/wuweipeng/Documents/MATLAB/MDID/distortion_images��';
%                for i=1:1
%                     FileName=dir(strcat(InputPath,'img05_06.bmp'));
%                     %tempFileName=FileName(i).name;
%                     %ImPath=strcat(InputPath,FileName);
%                     img=imread('/Users/wuweipeng/Documents/MATLAB/MDID/distortion_images/img05_06.bmp');
%                     quality= biqi(img); 
%                     %nrss=NRSS(img);
%                     %quality=gray_hist(img);
%                     sum=sum+quality;
%                     a=[a quality];
%                     %quality = Filter_wn_score(img);
%                     %quality=NRSS(img);
%                     %hsv=rgb2hsv(img);
%                     %H=hsv(:,:,1);
%                     %S=hsv(:,:,2);
%                     %V=hsv(:,:,3);
%                     i
%                end
%         %a=sum/10;
%         
%         a
%   
% % fid=fopen('/Users/wuweipeng/Desktop/1.txt','wt');%д���ļ�·��
% % [m,n]=size(a);                   %��ȡ����Ĵ�С��?ΪҪ����ľ���?% for i=1:1:m
% % for j=1:1:n
% % fprintf(fid,'%4.3f\n',a(i,j)); 
% % 
% % end
% % end
% % fclose(fid);
% %        
% %      
% % 
% % 
% % 
% 

%   This program calculates the distance, velocity and acceleration of a car.
%   This program is written by mingzi bao.
%   Program name; car.m

clear
clf
t=[0:0.1:10]';
accel=0.5.*t;
vel=accel.*t;
dist=vel.*t;
data=[dist vel accel] 
save data 
save car_data.txt data -ascii
figure(1)
plot(dist,vel)
%hold on
figure(2)
plot(dist,accel,'r')
%hold off

